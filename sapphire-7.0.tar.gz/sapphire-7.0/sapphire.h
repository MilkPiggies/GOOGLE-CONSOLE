/*
 * sapphire.h
 *
 * Copyright Mark Lord <mlord@pobox.com>, 2012-2018.
 * http://rtr.ca/sapphire_remote/
 *
 * Button definitions shared with sapphire_keymap.sh
 * and the external glue driver.
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the Free
 * Software Foundation; specifically version 2 of the License (GPLv2).
 */
#include <linux/device.h>
#include <linux/hid.h>
#include <linux/module.h>
#include <linux/timer.h>
#include <linux/kref.h>
#include <linux/list.h>
#include <linux/proc_fs.h>
#include <linux/uaccess.h>

/*
 * These enum's are shared with external keymaps and the sapphire_keymap.sh script:
 */
enum {	/*
	 * BEGIN_PARSING (marker used by script that extracts these for sapphire_keymap.sh)
	 *
	 * Raw button values from the Sapphire remote:
	 *
	 */
	SAPPHIRE_UP		= 0x00520000 , /* UP             */
	SAPPHIRE_DOWN		= 0x00510000 , /* DOWN           */
	SAPPHIRE_RIGHT		= 0x004f0000 , /* RIGHT          */
	SAPPHIRE_LEFT		= 0x00500000 , /* LEFT           */
	SAPPHIRE_ENTEROK	= 0x00280000 , /* ENTER/OK       */
	SAPPHIRE_BACK		= 0x00040003 , /* BACK           */
	SAPPHIRE_PLAY		= 0x40000003 , /* PLAY           */
	SAPPHIRE_PAUSE		= 0x80000003 , /* PAUSE          */
	SAPPHIRE_VOLUP		= 0x00002003 , /* VOL+           */
	SAPPHIRE_VOLDOWN	= 0x00004003 , /* VOL-           */
	SAPPHIRE_CHUP		= 0x00010003 , /* CH/PG+         */
	SAPPHIRE_CHDOWN		= 0x00020003 , /* CH/PG-         */
	SAPPHIRE_MUTE		= 0x00001003 , /* MUTE           */
	SAPPHIRE_RECORD		= 0x00008003 , /* RECORD         */
	SAPPHIRE_FWD		= 0x08000003 , /* FWD            */
	SAPPHIRE_REW		= 0x04000003 , /* REW            */
	SAPPHIRE_ANGLE		= 0x00010004 , /* ANGLE          */
	SAPPHIRE_SAP		= 0x00100004 , /* SAP            */
	SAPPHIRE_DVDMENU	= 0x00040004 , /* DVDMENU        */
	SAPPHIRE_INFOEPG	= 0x02000003 , /* INFO/EPG       */
	SAPPHIRE_TAB		= 0x00000103 , /* TAB            */
	SAPPHIRE_BACKTAB	= 0x00000203 , /* BACKTAB        */
	SAPPHIRE_RADIO		= 0x00000403 , /* RADIO          */
	SAPPHIRE_LASTCH		= 0x00400004 , /* LASTCH         */
	SAPPHIRE_LANGUAGE	= 0x00020004 , /* LANGUAGE       */
	SAPPHIRE_TELETEXTCC	= 0x00200004 , /* TELETEXT/CC    */
	SAPPHIRE_SUBTITLE	= 0x00080004 , /* SUBTITLE       */
	SAPPHIRE_HOMEHOUSE	= 0x00000104 , /* HOME (house)   */
	SAPPHIRE_BLUEVIDEOS	= 0x00002004 , /* BLUE/VIDEOS    */
	SAPPHIRE_LIVETV		= 0x00000204 , /* LIVETV         */
	SAPPHIRE_REDDVDVCD	= 0x00008004 , /* RED/DVD/VCD    */
	SAPPHIRE_YELLOWPICTURES	= 0x00001004 , /* YELLOW/PICTURES*/
	SAPPHIRE_1		= 0x001e0000 , /* 1              */
	SAPPHIRE_2		= 0x001f0000 , /* 2              */
	SAPPHIRE_3		= 0x00200000 , /* 3              */
	SAPPHIRE_4		= 0x00210000 , /* 4              */
	SAPPHIRE_5		= 0x00220000 , /* 5              */
	SAPPHIRE_6		= 0x00230000 , /* 6              */
	SAPPHIRE_7		= 0x00240000 , /* 7              */
	SAPPHIRE_8		= 0x00250000 , /* 8              */
	SAPPHIRE_9		= 0x00260000 , /* 9              */
	SAPPHIRE_0		= 0x00270000 , /* 0              */
	SAPPHIRE_STOP		= 0x00100003 , /* STOP           */
	SAPPHIRE_POWER		= 0x00000202 , /* POWER          */
	SAPPHIRE_CLEAR		= 0x004c0000 , /* CLEAR          */
	SAPPHIRE_GREENMUSIC	= 0x00000804 , /* GREEN/MUSIC    */

	/*
	 * A second set of "virtual" sapphire buttons,
	 * not for normal mapping use.  Instead, these are
	 * intended for use with the external "glue" module.
	 * If you don't know what that is, then just ignore these!
	 */
	XAPPHIRE_UP		= 0x005200f0 , /* UP             */
	XAPPHIRE_DOWN		= 0x005100f0 , /* DOWN           */
	XAPPHIRE_RIGHT		= 0x004f00f0 , /* RIGHT          */
	XAPPHIRE_LEFT		= 0x005000f0 , /* LEFT           */
	XAPPHIRE_ENTEROK	= 0x002800f0 , /* ENTER/OK       */
	XAPPHIRE_BACK		= 0x000400f3 , /* BACK           */
	XAPPHIRE_PLAY		= 0x400000f3 , /* PLAY           */
	XAPPHIRE_PAUSE		= 0x800000f3 , /* PAUSE          */
	XAPPHIRE_VOLUP		= 0x000020f3 , /* VOL+           */
	XAPPHIRE_VOLDOWN	= 0x000040f3 , /* VOL-           */
	XAPPHIRE_CHUP		= 0x000100f3 , /* CH/PG+         */
	XAPPHIRE_CHDOWN		= 0x000200f3 , /* CH/PG-         */
	XAPPHIRE_MUTE		= 0x000010f3 , /* MUTE           */
	XAPPHIRE_RECORD		= 0x000080f3 , /* RECORD         */
	XAPPHIRE_FWD		= 0x080000f3 , /* FWD            */
	XAPPHIRE_REW		= 0x040000f3 , /* REW            */
	XAPPHIRE_ANGLE		= 0x000100f4 , /* ANGLE          */
	XAPPHIRE_SAP		= 0x001000f4 , /* SAP            */
	XAPPHIRE_DVDMENU	= 0x000400f4 , /* DVDMENU        */
	XAPPHIRE_INFOEPG	= 0x020000f3 , /* INFO/EPG       */
	XAPPHIRE_TAB		= 0x000001f3 , /* TAB            */
	XAPPHIRE_BACKTAB	= 0x000002f3 , /* BACKTAB        */
	XAPPHIRE_RADIO		= 0x000004f3 , /* RADIO          */
	XAPPHIRE_LASTCH		= 0x004000f4 , /* LASTCH         */
	XAPPHIRE_LANGUAGE	= 0x000200f4 , /* LANGUAGE       */
	XAPPHIRE_TELETEXTCC	= 0x002000f4 , /* TELETEXT/CC    */
	XAPPHIRE_SUBTITLE	= 0x000800f4 , /* SUBTITLE       */
	XAPPHIRE_HOMEHOUSE	= 0x000001f4 , /* HOME (house)   */
	XAPPHIRE_BLUEVIDEOS	= 0x000020f4 , /* BLUE/VIDEOS    */
	XAPPHIRE_LIVETV		= 0x000002f4 , /* LIVETV         */
	XAPPHIRE_REDDVDVCD	= 0x000080f4 , /* RED/DVD/VCD    */
	XAPPHIRE_YELLOWPICTURES	= 0x000010f4 , /* YELLOW/PICTURES*/
	XAPPHIRE_1		= 0x001e00f0 , /* 1              */
	XAPPHIRE_2		= 0x001f00f0 , /* 2              */
	XAPPHIRE_3		= 0x002000f0 , /* 3              */
	XAPPHIRE_4		= 0x002100f0 , /* 4              */
	XAPPHIRE_5		= 0x002200f0 , /* 5              */
	XAPPHIRE_6		= 0x002300f0 , /* 6              */
	XAPPHIRE_7		= 0x002400f0 , /* 7              */
	XAPPHIRE_8		= 0x002500f0 , /* 8              */
	XAPPHIRE_9		= 0x002600f0 , /* 9              */
	XAPPHIRE_0		= 0x002700f0 , /* 0              */
	XAPPHIRE_STOP		= 0x001000f3 , /* STOP           */
	XAPPHIRE_POWER		= 0x000002f2 , /* POWER          */
	XAPPHIRE_CLEAR		= 0x004c00f0 , /* CLEAR          */
	XAPPHIRE_GREENMUSIC	= 0x000008f4 , /* GREEN/MUSIC    */

	/*
	 * Modifier buttons: "OR" these with "regular" KEY_ values as desired:
	 */
	CTRL			= 0x80000000 ,
	SHIFT			= 0x40000000 ,
	ALT			= 0x20000000 ,
	META			= 0x10000000 ,

	/*
	 * Special "macro" keys:
	 */
	KEY_DELAY		= 0x00fffff7 ,
	KEY_MACRO_0		= 0x00fffff8 ,
	KEY_MACRO_1		= 0x00fffff9 ,
	KEY_MACRO_2		= 0x00fffffa ,
	KEY_MACRO_3		= 0x00fffffb ,
	KEY_MACRO_4		= 0x00fffffc ,
	KEY_MACRO_5		= 0x00fffffd ,
	KEY_MACRO_6		= 0x00fffffe ,
	KEY_MACRO_7		= 0x00ffffff ,

	/*
	 * Per-button automatic repeat rates:
	 */
	NO_REPEAT		= 0x00000000 ,	/* no autorepeat */
	SLOW_REPEAT		= 0x00000004 ,	/* repeats 4 times per second */
	FAST_REPEAT		= 0x00000008 ,	/* repeats 8 times per second */
	RAMP_REPEAT		= 0x00000003 ,	/* repeats increase in rate as button is held, up to 10/sec */
	RAWKEY			= 0xffffffff ,	/* do not send "release" event until button is really released */
	LONGKEY			= 0x08000000 ,	/* no autorepeat; short/long presses send different codes */
};

/*
 * This is a hook for external modules to tie into,
 * allowing other remote-drivers to use the sapphire
 * driver's translations and advanced features.
 */
extern void sapphire_relay (u32 data);
