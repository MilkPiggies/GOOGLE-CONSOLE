#!/bin/bash
#
# Extract button and key definitions from sapphire.h and input.h:
#

function parse_sapphire_h(){
	echo
	echo "## buttons, macros, and other definitions extracted from $1:"
	echo "##"
	gawk '
		($2 == "BEGIN_PARSING"){c=1;next}
		(c == 0){next}
		/^	[XS]APPHIRE_([A-Z0-9_]+)\>([ 	]+)= 0x/{printf "B[%s]=%s\n",$1,$3;next}
		/^	KEY_MACRO_[0-7]\>([ 	]+)= 0x/{printf "B[%s]=0x%08x\n",$1,strtonum($3)}
		/^	KEY_([A-Z0-9_]+)\>([ 	]+)= 0x/{printf "K[%s]=0x%08x\n",$1,strtonum($3);next}
		/^	([A-Z0-9_]+)\>([ 	]+)= 0x/{printf "M[%s]=0x%08x\n",$1,strtonum($3);next}
		/^[}];/{if (c == 1) nextfile}
	' < "$1"
}

function parse_input_h(){
	echo
	echo "## keycodes extracted from $1:"
	echo "##"
	gawk '	/^#define KEY_([A-Z0-9_]+)\>([ 	]+)((0x[0-9a-fA-F]+)|([0-9]+))\>/{
			printf "K[%s]=0x%08x\n",$2,strtonum($3)}
	' < "$1" | grep -v KEY_RESERVED
}

parse_input_h "$1" && parse_sapphire_h "$2"

